#FIXME: Contribute back. When doing so, note that this appears to be required
#*ONLY* for scipy >= 0.15.0.
hiddenimports = ['scipy.integrate']
